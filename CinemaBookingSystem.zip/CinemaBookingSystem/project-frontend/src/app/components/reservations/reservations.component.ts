import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reservations',
  templateUrl: './reservations.component.html',
  styleUrls: ['./reservations.component.css']
})
export class ReservationsComponent implements OnInit {
  reservations: any[] = []; // Stores the list of reservations

  constructor() {}

  ngOnInit() {
    this.fetchReservations();
  }

  fetchReservations() {
    // Simulate an API call to fetch reservations
    fetch('http://localhost:3000/api/reservations')
      .then(response => response.json())
      .then(data => {
        this.reservations = data;
        console.log('Reservations fetched:', this.reservations);
      })
      .catch(error => {
        console.error('Error fetching reservations:', error);
      });
  }
}
