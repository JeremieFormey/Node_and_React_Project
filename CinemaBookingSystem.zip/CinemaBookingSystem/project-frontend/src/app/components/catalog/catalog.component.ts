import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catalog',
  templateUrl: './catalog.component.html',
})
export class CatalogComponent implements OnInit {
  movies = [];
  columnDefs = [
    { headerName: 'Title', field: 'title' },
    { headerName: 'Genre', field: 'genre' },
    { headerName: 'Showtimes', field: 'showtimes' },
  ];

  ngOnInit() {
    // Fetch movies from backend
    fetch('http://localhost:3000/api/movies')
      .then((res) => res.json())
      .then((data) => (this.movies = data));
  }
}
