CREATE TABLE movies (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    genre VARCHAR(50),
    showtimes TEXT[]
);

CREATE TABLE reservations (
    id SERIAL PRIMARY KEY,
    movie_id INT REFERENCES movies(id),
    user_name VARCHAR(100),
    seats INT,
    time TIMESTAMP
);
