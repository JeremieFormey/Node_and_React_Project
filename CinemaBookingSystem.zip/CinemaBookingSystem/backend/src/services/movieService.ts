import { Movie } from '../models/movie';

let movies: Movie[] = [
    { id: 1, title: 'Inception', description: 'Sci-fi thriller', genre: 'Sci-fi', showtimes: ['18:00', '20:30'] }
];

export const getAllMovies = async (): Promise<Movie[]> => movies;

export const addMovie = async (movie: Movie): Promise<Movie> => {
    movie.id = movies.length + 1;
    movies.push(movie);
    return movie;
};
