import express from 'express';
import movieRoutes from './routes/movies';
import reservationRoutes from './routes/reservations';

const app = express();
const PORT = 3000;

app.use(express.json());

// Routes
app.use('/api/movies', movieRoutes);
app.use('/api/reservations', reservationRoutes);
app.get('/', (req, res) => {
    res.send('Backend is running!');
  });
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
