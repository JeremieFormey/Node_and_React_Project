CREATE TABLE movies (
    id SERIAL PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    genre VARCHAR(50),
    duration INTEGER,
    showtimes TIMESTAMP[]
);

CREATE TABLE reservations (
    id SERIAL PRIMARY KEY,
    movie_id INTEGER REFERENCES movies(id),
    user_name VARCHAR(100),
    seats_reserved INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
