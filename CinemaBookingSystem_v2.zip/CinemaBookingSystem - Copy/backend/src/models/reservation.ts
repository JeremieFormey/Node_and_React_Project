export interface Reservation {
    id: number;
    movieId: number;
    userName: string;
    seats: number;
    time: string;
}
