import { Reservation } from '../models/reservation';

let reservations: Reservation[] = [];

export const getAllReservations = async (): Promise<Reservation[]> => reservations;

export const addReservation = async (reservation: Reservation): Promise<Reservation> => {
    reservation.id = reservations.length + 1;
    reservations.push(reservation);
    return reservation;
};
