import { Request, Response } from 'express';
import { getAllMovies, addMovie } from '../services/movieService';

export const getMovies = async (req: Request, res: Response) => {
    const movies = await getAllMovies();
    res.json(movies);
};

export const createMovie = async (req: Request, res: Response) => {
    const newMovie = await addMovie(req.body);
    res.status(201).json(newMovie);
};
