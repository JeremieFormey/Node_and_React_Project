import { Request, Response } from 'express';
import { getAllReservations, addReservation } from '../services/reservationService';

export const getReservations = async (req: Request, res: Response) => {
    const reservations = await getAllReservations();
    res.json(reservations);
};

export const createReservation = async (req: Request, res: Response) => {
    const newReservation = await addReservation(req.body);
    res.status(201).json(newReservation);
};
