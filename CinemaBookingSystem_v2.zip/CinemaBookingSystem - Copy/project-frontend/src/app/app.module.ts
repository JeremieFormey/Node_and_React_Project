import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router'; // Import RouterModule
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { CatalogComponent } from './components/catalog/catalog.component';
import { MakeReservationComponent } from './components/make-reservation/make-reservation.component';
import { ReservationsComponent } from './components/reservations/reservations.component';

@NgModule({
  declarations: [
    AppComponent,
    CatalogComponent,
    MakeReservationComponent,
    ReservationsComponent,
  ],
  imports: [
    BrowserModule,
    RouterModule, // Ensure RouterModule is here
    AppRoutingModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
