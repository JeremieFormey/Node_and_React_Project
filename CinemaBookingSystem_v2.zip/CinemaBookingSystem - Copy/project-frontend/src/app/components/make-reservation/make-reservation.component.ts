import { Component } from '@angular/core';

@Component({
  selector: 'app-make-reservation',
  templateUrl: './make-reservation.component.html',
  styleUrls: ['./make-reservation.component.css']
})
export class MakeReservationComponent {
  reservation = {
    movieId: null,
    userName: '',
    seats: null,
    time: ''
  };

  constructor() {}

  submitReservation() {
    // Simulate an API call to send reservation data
    console.log('Reservation submitted:', this.reservation);

    // You would typically send this data to your backend
    fetch('http://localhost:3000/api/reservations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(this.reservation),
    })
      .then(response => response.json())
      .then(data => {
        console.log('Success:', data);
        alert('Reservation successful!');
      })
      .catch(error => {
        console.error('Error:', error);
        alert('Failed to make reservation.');
      });

    // Clear the form after submission
    this.reservation = {
      movieId: null,
      userName: '',
      seats: null,
      time: ''
    };
  }
}

