import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CatalogComponent } from './components/catalog/catalog.component';
import { MakeReservationComponent } from './components/make-reservation/make-reservation.component';
import { ReservationsComponent } from './components/reservations/reservations.component';

const routes: Routes = [
  { path: '', redirectTo: 'catalog', pathMatch: 'full' }, // Redirect default route to catalog
  { path: 'catalog', component: CatalogComponent },
  { path: 'make-reservation', component: MakeReservationComponent },
  { path: 'reservations', component: ReservationsComponent },
  { path: '**', redirectTo: 'catalog' }, // Wildcard route to redirect to catalog
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
